Kodi Vimu 外部播放器配置
=======================

使用顺序：
1. 在电视上 Kodi 设置 → 服务 → 控制，开启“允许通过 HTTP 远程控制”，记住端口和账户密码。
2. 在 Kodi 的 视频→文件，添加 SMB 来源，确保 Kodi 内播放视频正常。
3. 如果希望手机点播后由 Vimu 播放：
   a) 确认 Vimu 已安装、能独立读取同一个 SMB 共享（如果 Vimu 需要认证，先在 Vimu 中配置）。
   b) 查 Vimu 实际包名：正式 Google Play 版通常是 net.gtvbox.videoplayer；免费版可能是 net.gtvbox.vimuhd。
   c) 从本目录选对应 XML；根据实际包名核对 <filename>。
   d) 重命名为 playercorefactory.xml 复制到 Kodi userdata 目录，退出并重启 Kodi。
       Android/data/org.xbmc.kodi/files/.kodi/userdata/playercorefactory.xml
       也可以通过 Kodi 文件管理器的 special://masterprofile/ 路径操作。
   e) 首次在 Kodi 本机上点播一个 SMB 影片验证它是否调用 Vimu，然后再从手机点播。

Google TV Android/data 文件夹可能受系统访问限制，请用 Kodi 自带文件管理器或有访问权限的文件管理器。
必要时请先备份原始 playercorefactory.xml，故障时删掉此文件并重启 Kodi 即可回到内部播放器。

重要限制：
- 外部 Vimu 接管后，Kodi JSON-RPC 不再掌握 Vimu 的暂停、进度和音量。
- Kodi 对外部播放器一般不会同步精确断点；Vimu 有自己的断点管理。
- 文件夹封面优先使用 Kodi 已有 artwork，缺失时尝试同名图片、poster.jpg、folder.jpg；未刮削影片不一定有缩微图。
- SMB 凭据保存在 Kodi/Vimu 自身，手机端只配置 Kodi HTTP 账号。
