package com.plexstyle.kodivimu;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.util.LruCache;
import android.widget.ImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class KodiClient {
    static final ExecutorService WORK = Executors.newFixedThreadPool(5);
    private final Context context;
    private final LruCache<String, Bitmap> imageCache = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
    };
    KodiClient(Context context) { this.context = context.getApplicationContext(); }
    SharedPreferences prefs() { return context.getSharedPreferences("kodi", Context.MODE_PRIVATE); }
    String host() { return prefs().getString("host", "192.168.0.79").trim(); }
    int port() { return prefs().getInt("port", 8080); }
    String user() { return prefs().getString("user", "kodi"); }
    String password() { return prefs().getString("password", ""); }
    boolean configured() { return host().length() > 0 && port() >= 1 && port() <= 65535; }
    String baseUrl() { return "http://" + host() + ":" + port(); }

    private HttpURLConnection connect(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(12000);
        c.setUseCaches(true);
        if (!user().isEmpty()) {
            String auth = user() + ":" + password();
            c.setRequestProperty("Authorization", "Basic " + Base64.encodeToString(auth.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP));
        }
        return c;
    }
    JSONObject rpc(String method, JSONObject params) throws Exception {
        if (!configured()) throw new IOException("请先在设置里填写 Kodi 的 IP 和 HTTP 端口");
        JSONObject payload = new JSONObject();
        payload.put("jsonrpc", "2.0");
        payload.put("id", 1);
        payload.put("method", method);
        if (params != null) payload.put("params", params);
        HttpURLConnection c = connect(baseUrl() + "/jsonrpc");
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try {
            try (OutputStream out = c.getOutputStream()) {
                out.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("Kodi HTTP " + code + "（请检查用户名、密码、端口）");
            String txt;
            try (InputStream in = c.getInputStream()) { txt = read(in); }
            JSONObject response = new JSONObject(txt);
            if (response.has("error")) {
                JSONObject err = response.optJSONObject("error");
                throw new IOException("Kodi RPC: " + (err == null ? response.get("error") : err.optString("message")));
            }
            JSONObject result = response.optJSONObject("result");
            return result == null ? new JSONObject().put("value", response.opt("result")) : result;
        } finally { c.disconnect(); }
    }
    static JSONObject obj(Object... keyValue) throws JSONException {
        JSONObject v = new JSONObject();
        for (int i = 0; i < keyValue.length; i += 2) v.put((String) keyValue[i], keyValue[i+1]);
        return v;
    }
    static JSONArray arr(String... values) {
        JSONArray a = new JSONArray();
        for (String s : values) a.put(s);
        return a;
    }
    JSONArray getMovies() throws Exception {
        JSONObject p = obj("properties", arr("title","year","plot","rating","runtime","thumbnail","art","resume","playcount","file","genre"),
                "sort", obj("method","dateadded","order","descending"), "limits", obj("start",0,"end",500));
        try { return rpc("VideoLibrary.GetMovies", p).optJSONArray("movies"); }
        catch (Exception first) {
            p.remove("sort");
            return rpc("VideoLibrary.GetMovies", p).optJSONArray("movies");
        }
    }
    JSONArray getShows() throws Exception {
        JSONObject p = obj("properties", arr("title","year","plot","rating","thumbnail","art","playcount","genre"),
                "sort", obj("method","dateadded","order","descending"), "limits", obj("start",0,"end",250));
        try { return rpc("VideoLibrary.GetTVShows", p).optJSONArray("tvshows"); }
        catch (Exception first) {
            p.remove("sort");
            return rpc("VideoLibrary.GetTVShows", p).optJSONArray("tvshows");
        }
    }
    JSONArray getEpisodes(int tvshowid) throws Exception {
        JSONObject p = obj("tvshowid",tvshowid,
                "properties",arr("title","plot","thumbnail","art","file","season","episode","runtime","playcount","resume"),
                "sort",obj("method","episode","order","ascending"),"limits",obj("start",0,"end",600));
        return rpc("VideoLibrary.GetEpisodes",p).optJSONArray("episodes");
    }
    JSONArray getSources() throws Exception {
        return rpc("Files.GetSources", obj("media","video")).optJSONArray("sources");
    }
    JSONArray getDirectory(String directory) throws Exception {
        JSONObject params = obj("directory",directory,"media","files","properties",arr("title","thumbnail","art"));
        try { return rpc("Files.GetDirectory",params).optJSONArray("files"); }
        catch (Exception e) {
            // Some Kodi releases reject extra file fields: retry with the portable minimum.
            return rpc("Files.GetDirectory",obj("directory",directory,"media","files")).optJSONArray("files");
        }
    }
    void playFile(String file) throws Exception {
        rpc("Player.Open",obj("item",obj("file",file)));
    }
    int activePlayer() throws Exception {
        JSONArray players = rpc("Player.GetActivePlayers",null).optJSONArray("value");
        if (players == null || players.length() == 0) return -1;
        // Kodi returns a JSON array, which rpc() wraps in 'value'.
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = players.optJSONObject(i);
            if (p != null && "video".equals(p.optString("type"))) return p.optInt("playerid",-1);
        }
        JSONObject p = players.optJSONObject(0);
        return p == null ? -1 : p.optInt("playerid",-1);
    }
    JSONObject playerProperties(int playerid) throws Exception {
        return rpc("Player.GetProperties",obj("playerid",playerid,
                "properties",arr("speed","time","totaltime","percentage","position","canseek","canchangespeed")));
    }
    String playerItemTitle(int playerid) throws Exception {
        JSONObject v = rpc("Player.GetItem",obj("playerid",playerid,"properties",arr("title")));
        JSONObject item = v.optJSONObject("item");
        return item == null ? "正在播放" : item.optString("title",item.optString("label","正在播放"));
    }
    void playerCommand(String method, int playerId, Object k, Object v) throws Exception {
        JSONObject p = obj("playerid", playerId);
        if (k != null) p.put((String)k,v);
        rpc(method,p);
    }
    void volume(String action) throws Exception { rpc("Application.SetVolume",obj("volume",action)); }
    void mute() throws Exception { rpc("Application.SetMute",obj("mute","toggle")); }

    String thumbnailUrl(String kodiArt) {
        if (kodiArt == null || kodiArt.isEmpty()) return "";
        if (kodiArt.startsWith("vfs:")) return baseUrl()+"/vfs/"+Uri.encode(kodiArt.substring(4));
        if (kodiArt.startsWith("http://") || kodiArt.startsWith("https://")) return kodiArt;
        return baseUrl()+"/image/"+Uri.encode(kodiArt);
    }
    void loadImage(ImageView target, String imagePath) {
        if (imagePath == null || imagePath.isEmpty()) return;
        String key = baseUrl()+":"+imagePath;
        Bitmap cached;
        synchronized (imageCache) { cached = imageCache.get(key); }
        if (cached != null) { target.setImageBitmap(cached); return; }
        target.setTag(key);
        WORK.execute(() -> {
            Bitmap bitmap = null;
            HttpURLConnection c = null;
            try {
                c = connect(thumbnailUrl(imagePath));
                if (c.getResponseCode() == 200) {
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inSampleSize = 2;
                    try (InputStream in = c.getInputStream()) { bitmap = BitmapFactory.decodeStream(in,null,opts); }
                    if (bitmap != null) synchronized (imageCache) { imageCache.put(key,bitmap); }
                }
            } catch (Exception ignored) { /* missing art: keep visual fallback */ }
            finally { if (c != null) c.disconnect(); }
            final Bitmap result = bitmap;
            target.post(() -> {
                if (key.equals(target.getTag()) && result != null) target.setImageBitmap(result);
            });
        });
    }
    private static String read(InputStream in) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n=in.read(buf)) != -1) {
            bytes.write(buf,0,n);
            if (bytes.size() > 10 * 1024 * 1024) throw new IOException("Kodi response too large");
        }
        return bytes.toString("UTF-8");
    }
}
