package com.plexstyle.kodivimu;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BG = 0xFF080E18, SURFACE = 0xFF142135, TILE = 0xFF1B2C41;
    private static final int TEXT = 0xFFF3F8FF, SUB = 0xFFA3B4C9, ACCENT = 0xFF54E5D3;
    private static final String[] VIDEO_EXT = {".mkv", ".mp4", ".avi", ".mov", ".ts", ".m2ts", ".m4v", ".wmv", ".webm", ".flv", ".mpeg", ".mpg", ".vob", ".iso"};

    private KodiClient kodi;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout main, content, tabBar, homeContent;
    private int page = 0, requestId = 0, displayLimit = 60, activePlayerId = -1;
    private String searchText = "", folderCurrent = "";
    private String selectedShowName = "";
    private final ArrayDeque<String> folderParents = new ArrayDeque<>();
    private final List<Media> movies = new ArrayList<>(), shows = new ArrayList<>();
    private final List<Media> currentPlaylist = new ArrayList<>();
    private int currentPlaylistIndex = -1;
    private final Runnable poll = new Runnable() { @Override public void run() { if (page == 2) { refreshRemote(); handler.postDelayed(this, 3500); } } };

    static class Media {
        String title = "", file = "", artwork = "", fanart = "", plot = "", genre = "";
        int year, id, season, episode, playcount;
        double rating, resume;
        boolean folder, show;
        Media copy() {
            Media n = new Media(); n.title=title; n.file=file; n.artwork=artwork; n.fanart=fanart;
            n.plot=plot; n.genre=genre; n.year=year; n.id=id; n.season=season; n.episode=episode;
            n.playcount=playcount; n.rating=rating; n.resume=resume; n.folder=folder; n.show=show;
            return n;
        }
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        kodi = new KodiClient(this);
        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(BG);
        setContentView(main);
        renderShell();
        if (kodi.configured()) loadHome(); else navigate(3);
    }
    @Override protected void onStop() { super.onStop(); handler.removeCallbacks(poll); }
    @Override protected void onStart() { super.onStart(); if (page == 2) handler.post(poll); }
    private int dp(float n) { return (int)(getResources().getDisplayMetrics().density*n + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private GradientDrawable stroke(int color, int radius, int borderColor) {
        GradientDrawable d = bg(color,radius); d.setStroke(dp(1),borderColor); return d;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private TextView text(String t, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(size); v.setTextColor(color);
        v.setIncludeFontPadding(true); if (bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }
    private void padding(View v, int a, int b, int c, int d) { v.setPadding(dp(a),dp(b),dp(c),dp(d)); }
    private void gap(LinearLayout l, int px) { View v = new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(px))); }
    private void add(LinearLayout l, View v) { l.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    private void label(LinearLayout to, String t) { TextView v = text(t,20,TEXT,true); padding(v,0,6,0,13); add(to,v); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    private void async(Job job, Done done) {
        KodiClient.WORK.execute(() -> {
            try { Object result=job.run(); runOnUiThread(() -> done.done(result,null)); }
            catch (Exception e) { runOnUiThread(() -> done.done(null,e)); }
        });
    }
    interface Job { Object run() throws Exception; }
    interface Done { void done(Object data, Exception err); }
    private void error(LinearLayout to, String err) {
        TextView t = text("连接或读取失败\n"+err+"\n\n请到「设置」核对 Kodi HTTP 服务、IP、端口和账户。",14,SUB,false);
        padding(t,14,20,14,20); t.setBackground(bg(SURFACE,16)); add(to,t);
    }
    private Button button(String t, boolean bright) {
        Button b = new Button(this); b.setText(t); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(bright ? BG : TEXT); b.setBackground(bg(bright?ACCENT:TILE,14));
        b.setMinHeight(0); b.setMinimumHeight(0); padding(b,13,12,13,12); return b;
    }
    private void sectionAction(LinearLayout parent, String title, String action, Runnable onClick) {
        LinearLayout row=horizontal();
        TextView t=text(title,20,TEXT,true); row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        if (action != null) { TextView link=text(action+"  ›",13,ACCENT,true); padding(link,8,8,0,8); link.setOnClickListener(v->onClick.run()); row.addView(link); }
        add(parent,row); gap(parent,12);
    }
    private void renderShell() {
        main.removeAllViews();
        LinearLayout header=horizontal(); padding(header,20,14,17,12);
        TextView logo=text("◈",29,ACCENT,true); header.addView(logo);
        LinearLayout names=vertical(); padding(names,12,0,0,0);
        add(names,text("CINEMA  HUB",18,TEXT,true)); add(names,text("KODI  ×  VIMU  •  LOCAL MEDIA",10,SUB,false));
        header.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        TextView setting=text("⚙",24,SUB,false); padding(setting,13,3,8,3); setting.setOnClickListener(v->navigate(3)); header.addView(setting);
        add(main,header);
        View rule=new View(this); rule.setBackgroundColor(0xFF263447); main.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setVerticalScrollBarEnabled(false);
        content=vertical(); padding(content,18,15,18,24); scroll.addView(content);
        main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        tabBar=horizontal(); padding(tabBar,8,9,8,10); tabBar.setBackgroundColor(0xFF101C2B);
        main.addView(tabBar,new LinearLayout.LayoutParams(-1,-2));
        updateTabs();
    }
    private void updateTabs() {
        tabBar.removeAllViews();
        String[] titles={"⌂ 影视库","▤ SMB","◉ 遥控","⚙ 设置"};
        for (int i=0;i<titles.length;i++) {
            final int which=i; TextView t=text(titles[i],12,i==page?ACCENT:SUB,i==page);
            t.setGravity(Gravity.CENTER); padding(t,1,10,1,10);
            if (i==page) t.setBackground(bg(0xFF203A49,11));
            tabBar.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            t.setOnClickListener(v->navigate(which));
        }
    }
    private void navigate(int which) {
        page=which; requestId++; handler.removeCallbacks(poll);
        content.removeAllViews(); updateTabs();
        if (which==0) renderHome();
        else if (which==1) loadRootSources();
        else if (which==2) { renderRemote(); handler.post(poll); }
        else renderSettings();
    }
    private void loadHome() {
        page=0; updateTabs(); content.removeAllViews();
        add(content,text("正在读取 Kodi 影视资料库…",16,SUB,false));
        final int token=++requestId;
        async(() -> new JSONArray[]{kodi.getMovies(),kodi.getShows()}, (data,err)->{
            if (token!=requestId || page!=0) return;
            if (err!=null) {content.removeAllViews(); error(content,err.getMessage()); return;}
            JSONArray[] arrays=(JSONArray[])data;
            movies.clear(); shows.clear();
            appendMovies(arrays[0],movies,false); appendMovies(arrays[1],shows,true);
            renderHome();
        });
    }
    private void appendMovies(JSONArray arr, List<Media> out, boolean isShow) {
        if (arr==null) return;
        for (int i=0;i<arr.length();i++) {
            JSONObject j=arr.optJSONObject(i); if (j==null) continue;
            Media m=mediaFrom(j); m.show=isShow; m.id=j.optInt(isShow?"tvshowid":"movieid",-1);
            out.add(m);
        }
    }
    private static Media mediaFrom(JSONObject j) {
        Media m=new Media();
        m.title=j.optString("title",j.optString("label","未命名"));
        if (m.title.isEmpty()) m.title=j.optString("label","未命名");
        m.file=j.optString("file","");
        m.year=j.optInt("year",0); m.plot=j.optString("plot","");
        m.rating=j.optDouble("rating",0); m.playcount=j.optInt("playcount",0);
        JSONObject r=j.optJSONObject("resume"); m.resume=r==null?0:r.optDouble("position",0);
        m.season=j.optInt("season",0); m.episode=j.optInt("episode",0);
        JSONArray genres=j.optJSONArray("genre"); if (genres!=null && genres.length()>0) m.genre=genres.optString(0,"");
        JSONObject art=j.optJSONObject("art");
        if (art != null) { m.artwork=art.optString("poster",art.optString("thumb","")); m.fanart=art.optString("fanart",""); }
        if (m.artwork.isEmpty()) m.artwork=j.optString("thumbnail","");
        if (m.fanart.isEmpty()) m.fanart=j.optString("fanart","");
        return m;
    }
    private void renderHome() {
        content.removeAllViews();
        TextView sub=text("你的私人 4K 影音中心",13,ACCENT,true); add(content,sub); gap(content,5);
        add(content,text("发现下一部好电影",27,TEXT,true)); gap(content,13);
        EditText search=new EditText(this);
        search.setSingleLine(true); search.setHint("⌕ 搜索电影、剧集、文件名称"); search.setHintTextColor(0xFF8093A7);
        search.setTextColor(TEXT); search.setTextSize(14); search.setBackground(stroke(SURFACE,14,0xFF263B52));
        padding(search,15,12,15,12); search.setText(searchText); add(content,search); gap(content,18);
        homeContent=vertical(); add(content,homeContent);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                searchText=s.toString(); renderHomeItems();
            }
            @Override public void afterTextChanged(Editable e) {}
        });
        renderHomeItems();
    }
    private List<Media> filtered(List<Media> in) {
        if (searchText.trim().isEmpty()) return new ArrayList<>(in);
        String f=searchText.trim().toLowerCase(Locale.ROOT);
        List<Media> ret=new ArrayList<>();
        for (Media m:in) if (m.title.toLowerCase(Locale.ROOT).contains(f) || m.genre.toLowerCase(Locale.ROOT).contains(f)) ret.add(m);
        return ret;
    }
    private void renderHomeItems() {
        if (homeContent==null || page!=0) return;
        homeContent.removeAllViews();
        List<Media> filteredMovies=filtered(movies), filteredShows=filtered(shows);
        if (movies.isEmpty() && shows.isEmpty()) {
            TextView notice=text("Kodi 视频资料库还没有入库影片。\n\n你可以直接使用底部「SMB」浏览文件夹，也可以在电视 Kodi 中为影片目录设置内容并扫描影片库。",14,SUB,false);
            padding(notice,16,18,16,18); notice.setBackground(bg(SURFACE,14)); add(homeContent,notice);
            return;
        }
        if (searchText.isEmpty() && !movies.isEmpty()) { hero(homeContent,movies.get(0)); gap(homeContent,24); }
        List<Media> inProgress = new ArrayList<>();
        for (Media m: filteredMovies) if (m.resume>30) inProgress.add(m);
        if (!inProgress.isEmpty()) { sectionAction(homeContent,"继续观看",null,null); posterRail(homeContent,inProgress,12); gap(homeContent,23); }
        if (!filteredShows.isEmpty()) { sectionAction(homeContent,"电视剧",null,null); posterRail(homeContent,filteredShows,16); gap(homeContent,23); }
        sectionAction(homeContent,"电影库  ·  "+filteredMovies.size(),"刷新",this::loadHome);
        if (filteredMovies.isEmpty()) {add(homeContent,text("没有匹配的电影。",14,SUB,false)); return;}
        android.widget.GridLayout grid=new android.widget.GridLayout(this);
        grid.setColumnCount(2); grid.setAlignmentMode(android.widget.GridLayout.ALIGN_BOUNDS);
        add(homeContent,grid);
        int itemWidth=(getResources().getDisplayMetrics().widthPixels-dp(50))/2;
        for (int i=0;i<Math.min(displayLimit,filteredMovies.size());i++) {
            Media m=filteredMovies.get(i); View card=posterCard(m,itemWidth,dp(238));
            android.widget.GridLayout.LayoutParams lp=new android.widget.GridLayout.LayoutParams();
            lp.width=itemWidth;lp.height=-2;lp.setMargins(dp(3),0,dp(3),dp(13));
            grid.addView(card,lp);
        }
        if (filteredMovies.size()>displayLimit) {
            Button more=button("显示更多电影（剩余 "+(filteredMovies.size()-displayLimit)+" 部）",false);
            more.setOnClickListener(v->{displayLimit+=60;renderHomeItems();}); add(homeContent,more);
        }
    }
    private void hero(LinearLayout into, Media m) {
        FrameLayout frame=new FrameLayout(this); frame.setBackground(bg(SURFACE,20)); frame.setClipToOutline(true);
        into.addView(frame,new LinearLayout.LayoutParams(-1,dp(224)));
        ImageView back=new ImageView(this); back.setBackgroundColor(0xFF233B56); back.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(back,new FrameLayout.LayoutParams(-1,-1));
        kodi.loadImage(back,m.fanart.isEmpty()?m.artwork:m.fanart);
        View shade=new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xFA09111D,0xD80B1520,0x110D1420}));
        frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=vertical(); padding(info,19,0,19,19);
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM); frame.addView(info,ip);
        add(info,text("✦  本地精选",12,ACCENT,true)); gap(info,6);
        add(info,text(m.title,24,TEXT,true));
        String attrs=(m.year>0?m.year+"  ·  ":"")+(!m.genre.isEmpty()?m.genre+"  ·  ":"")+"KODI LIBRARY";
        add(info,text(attrs,11,0xFFD1DEE9,false)); gap(info,8);
        Button play=button("▶  电视播放",true); play.setOnClickListener(v->playItem(m,movies));
        info.addView(play,new LinearLayout.LayoutParams(dp(145),-2));
    }
    private void posterRail(LinearLayout into, List<Media> items, int n) {
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false); LinearLayout row=horizontal();
        for (int i=0;i<Math.min(n,items.size());i++) {
            Media m=items.get(i); View tile=posterCard(m,dp(146),dp(198));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(146),-2); lp.setMargins(0,0,dp(12),0);row.addView(tile,lp);
        }
        scroll.addView(row); add(into,scroll);
    }
    private View posterCard(Media m, int width, int coverHeight) {
        LinearLayout card=vertical();
        FrameLayout cover=new FrameLayout(this); cover.setBackground(bg(TILE,14)); cover.setClipToOutline(true);
        card.addView(cover,new LinearLayout.LayoutParams(width,coverHeight));
        TextView placeholder=text(m.show?"▣":"▶",38,0xFF6D859D,true);
        placeholder.setGravity(Gravity.CENTER); cover.addView(placeholder,new FrameLayout.LayoutParams(-1,-1));
        ImageView image=new ImageView(this); image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.addView(image,new FrameLayout.LayoutParams(-1,-1)); kodi.loadImage(image,m.artwork);
        if (m.playcount>0) {
            TextView watched=text("✓ 已看",10,TEXT,true);padding(watched,5,3,5,3); watched.setBackground(bg(0xBB0E2431,6));
            FrameLayout.LayoutParams wp=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.TOP);wp.setMargins(0,dp(8),dp(8),0);cover.addView(watched,wp);
        }
        TextView name=text(m.title,13,TEXT,true);name.setMaxLines(2); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        padding(name,2,8,2,1); add(card,name);
        String desc=m.show?"电视剧":(m.year>0?""+m.year:"本地影片");
        TextView small=text(desc,11,SUB,false);padding(small,2,0,0,0);add(card,small);
        card.setOnClickListener(v->openDetail(m)); return card;
    }
    private void openDetail(Media m) {
        LinearLayout layout=vertical();padding(layout,20,12,20,8);
        if (!m.artwork.isEmpty()) {
            ImageView banner=new ImageView(this);banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
            layout.addView(banner,new LinearLayout.LayoutParams(-1,dp(160)));
            kodi.loadImage(banner,m.fanart.isEmpty()?m.artwork:m.fanart); gap(layout,12);
        }
        add(layout,text(m.title,22,TEXT,true));gap(layout,9);
        String meta=(m.year>0?""+m.year:"")+(m.rating>0?"   ★ "+String.format(Locale.US,"%.1f",m.rating):"");
        if (m.show) meta += "  ·  电视剧";
        add(layout,text(meta,13,ACCENT,false));gap(layout,12);
        if (!m.plot.isEmpty()) {TextView plot=text(m.plot,13,SUB,false);plot.setMaxLines(9);add(layout,plot);gap(layout,10);}
        AlertDialog.Builder dlg=new AlertDialog.Builder(this).setView(layout).setNegativeButton("关闭",null);
        if (m.show) dlg.setPositiveButton("查看剧集",(d,w)->loadEpisodes(m));
        else dlg.setPositiveButton("▶ 电视播放",(d,w)->playItem(m,movies));
        dlg.show();
    }
    private void loadEpisodes(Media show) {
        if (show.id<0) {toast("该电视剧没有有效的 Kodi ID");return;}
        page=0; requestId++; final int token=requestId;updateTabs();content.removeAllViews();
        Button back=button("‹ 返回影视库",false);back.setOnClickListener(v->renderHome());add(content,back);gap(content,18);
        add(content,text(show.title,25,TEXT,true)); gap(content,8);
        add(content,text("正在读取剧集…",14,SUB,false));
        async(()->kodi.getEpisodes(show.id),(data,err)->{
            if (token!=requestId || page!=0) return;
            content.removeAllViews();Button go=button("‹ 返回影视库",false);go.setOnClickListener(v->renderHome());add(content,go);gap(content,16);
            add(content,text(show.title,25,TEXT,true));gap(content,16);
            if (err!=null) {error(content,err.getMessage());return;}
            JSONArray a=(JSONArray)data;
            List<Media> episodes=new ArrayList<>();
            if(a!=null) for(int i=0;i<a.length();i++) {
                JSONObject j=a.optJSONObject(i);if(j==null)continue;
                Media m=mediaFrom(j);m.title=String.format(Locale.US,"S%02dE%02d  %s",m.season,m.episode,m.title);
                episodes.add(m);
            }
            if(episodes.isEmpty())add(content,text("该剧尚未扫描出剧集。",14,SUB,false));
            for(Media m:episodes) fileRow(content,m,episodes);
        });
    }
    private void playItem(Media m,List<Media> playlist) {
        if (m.file==null || m.file.isEmpty()) {toast("此项目没有可播放的文件路径");return;}
        currentPlaylist.clear(); for(Media one:playlist) if(one.file!=null&&!one.file.isEmpty())currentPlaylist.add(one.copy());
        currentPlaylistIndex=-1;
        for(int i=0;i<currentPlaylist.size();i++) if(currentPlaylist.get(i).file.equals(m.file)) {currentPlaylistIndex=i;break;}
        async(()->{kodi.playFile(m.file);return null;},(data,err)->{
            if(err!=null)toast("播放失败："+err.getMessage());
            else toast("已发送到 Kodi。是否交由 Vimu 播放，由电视上的 playercorefactory.xml 决定。");
        });
    }
    private void switchPlaylist(int delta) {
        if (currentPlaylist.isEmpty() || currentPlaylistIndex<0) {toast("请先从影视库或 SMB 列表选择一部影片");return;}
        int n=currentPlaylistIndex+delta;
        if(n<0||n>=currentPlaylist.size()){toast("已经到列表边界");return;}
        Media m=currentPlaylist.get(n);currentPlaylistIndex=n;
        async(()->{kodi.playFile(m.file);return null;},(data,err)->{
            if(err!=null) toast("切换失败："+err.getMessage());else toast("已发送："+m.title);
        });
    }
    private void loadRootSources() {
        folderParents.clear();folderCurrent="";loadFolder(true);
    }
    private void loadFolder(boolean root) {
        page=1;updateTabs();content.removeAllViews();final String directory=folderCurrent;
        final int token=++requestId;
        add(content,text(root?"SMB / 网络视频源":"文件目录",24,TEXT,true));gap(content,10);
        add(content,text("由电视端 Kodi 浏览 SMB；手机无需保存 SMB 账户密码。",12,SUB,false));gap(content,14);
        if(!root) {
            Button up=button("‹ 返回上一级",false);up.setOnClickListener(v->goFolderBack());add(content,up);gap(content,10);
            TextView path=text(directory,11,SUB,false);add(content,path);gap(content,13);
        }
        add(content,text("读取中…",14,SUB,false));
        async(()->root?kodi.getSources():kodi.getDirectory(directory),(data,err)->{
            if(token!=requestId||page!=1)return;
            content.removeAllViews();add(content,text(root?"SMB / 网络视频源":"文件目录",24,TEXT,true));gap(content,10);
            if(!root){
                Button up=button("‹ 返回上一级",false);up.setOnClickListener(v->goFolderBack());add(content,up);gap(content,7);
                add(content,text(directory,11,SUB,false));gap(content,10);
            }
            if(err!=null){error(content,err.getMessage());return;}
            JSONArray a=(JSONArray)data;
            List<Media> files=new ArrayList<>();Map<String,String> covers=new HashMap<>();
            if(a!=null) for(int i=0;i<a.length();i++) {
                JSONObject j=a.optJSONObject(i);if(j==null)continue;
                Media m=mediaFrom(j);
                if(m.file.isEmpty())continue;
                m.title=j.optString("label",m.title);
                m.folder=root||"directory".equals(j.optString("filetype",""));
                if(m.folder && m.title.endsWith("/"))m.title=m.title.substring(0,m.title.length()-1);
                if(!m.folder){
                    if(isPicture(m.file))covers.put(baseName(m.file).toLowerCase(Locale.ROOT),m.file);
                    if(!isVideo(m.file))continue;
                }
                files.add(m);
            }
            for(Media m:files){
                if(!m.artwork.isEmpty())continue;
                String base=baseName(m.file).toLowerCase(Locale.ROOT);
                String candidate=covers.get(base);
                if(candidate==null)candidate=covers.get("poster");
                if(candidate==null)candidate=covers.get("folder");
                if(candidate!=null) m.artwork="vfs:"+candidate;
            }
            if(root && files.isEmpty()) {
                add(content,text("Kodi 尚未设置视频来源。请先在电视 Kodi 中添加 SMB 目录，然后重新打开此页面。",14,SUB,false));
            } else if(files.isEmpty()) add(content,text("这里没有可见的视频文件或子文件夹。",14,SUB,false));
            for(Media m:files)fileRow(content,m,files);
            gap(content,16);
            Button reload=button("↻ 刷新当前目录",false);reload.setOnClickListener(v->loadFolder(root));add(content,reload);
        });
    }
    private void fileRow(LinearLayout into, Media m,List<Media> playlist) {
        LinearLayout row=horizontal();padding(row,9,9,11,9);row.setBackground(bg(SURFACE,13));
        if(!m.folder && !m.artwork.isEmpty()) {
            ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            row.addView(thumb,new LinearLayout.LayoutParams(dp(78),dp(64)));kodi.loadImage(thumb,m.artwork);
        } else {
            TextView icon=text(m.folder?"▣":"▶",22,m.folder?ACCENT:SUB,true);icon.setGravity(Gravity.CENTER);
            icon.setBackground(bg(TILE,10));row.addView(icon,new LinearLayout.LayoutParams(dp(78),dp(64)));
        }
        LinearLayout meta=vertical();padding(meta,12,0,0,0);
        TextView title=text(m.title,14,TEXT,true);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        add(meta,title);gap(meta,5);
        add(meta,text(m.folder?"文件夹  ·  点击进入":"视频  ·  点击电视播放",11,SUB,false));
        row.addView(meta,new LinearLayout.LayoutParams(0,-2,1));
        add(into,row);gap(into,8);
        row.setOnClickListener(v->{
            if(m.folder) {folderParents.push(folderCurrent);folderCurrent=m.file;loadFolder(false);}
            else playItem(m,playlist);
        });
    }
    private static String baseName(String path) {
        String name=path.substring(path.lastIndexOf('/')+1);
        int dot=name.lastIndexOf('.');return dot>0?name.substring(0,dot):name;
    }
    private static boolean isPicture(String path) {
        String s=path.toLowerCase(Locale.ROOT);return s.endsWith(".jpg")||s.endsWith(".jpeg")||s.endsWith(".png")||s.endsWith(".webp");
    }
    private static boolean isVideo(String path) {
        String s=path.toLowerCase(Locale.ROOT);
        for(String ext:VIDEO_EXT)if(s.endsWith(ext))return true;
        return false;
    }
    private void goFolderBack(){
        if(folderParents.isEmpty())loadRootSources();
        else{folderCurrent=folderParents.pop();loadFolder(folderCurrent.isEmpty());}
    }
    @Override public void onBackPressed() {
        if(page==1&&!folderCurrent.isEmpty())goFolderBack();
        else if(page!=0)navigate(0);
        else super.onBackPressed();
    }
    private TextView remoteStatus;
    private SeekBar remoteSeek;
    private void renderRemote() {
        add(content,text("播放控制台",26,TEXT,true));gap(content,12);
        TextView info=text("手机直接控制 Kodi 内置播放器。若视频已交给 Vimu，Kodi 不再掌握 Vimu 的进度、暂停和音量；这时请用电视遥控器操作。",13,SUB,false);
        padding(info,16,16,16,16);info.setBackground(stroke(SURFACE,14,0xFF344456));add(content,info);gap(content,16);
        LinearLayout statusBox=vertical();padding(statusBox,18,17,18,17);statusBox.setBackground(bg(SURFACE,16));
        add(statusBox,text("NOW PLAYING  •  KODI",12,ACCENT,true));gap(statusBox,9);
        remoteStatus=text("检查 Kodi 播放状态…",16,TEXT,true);add(statusBox,remoteStatus);gap(statusBox,9);
        remoteSeek=new SeekBar(this);remoteSeek.setMax(1000);remoteSeek.setProgress(0);
        add(statusBox,remoteSeek);gap(statusBox,8);
        remoteSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar s,int progress,boolean user){}
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){
                int id=activePlayerId;if(id<0){toast("Kodi 没有活动播放器");return;}
                int value=s.getProgress();
                async(()->{kodi.playerCommand("Player.Seek",id,"value",KodiClient.obj("percentage",value/10.0));return null;},(o,e)->{
                    if(e!=null)toast(e.getMessage());
                });
            }
        });
        add(content,statusBox);gap(content,20);
        rowButtons(content,new String[]{"⏮ 上一部","⏪ 后退10秒","⏩ 前进10秒","下一部 ⏭"},
                new Runnable[]{()->switchPlaylist(-1),()->seek(-10),()->seek(10),()->switchPlaylist(1)});
        gap(content,12);
        rowButtons(content,new String[]{"▶ / Ⅱ 播放暂停","■ 停止"},new Runnable[]{()->playerAction("Player.PlayPause",null,null),()->playerAction("Player.Stop",null,null)});
        gap(content,20);label(content,"音量  ·  Kodi 应用");
        rowButtons(content,new String[]{"− 音量","静音","+ 音量"},new Runnable[]{()->volume("decrement"),()->mute(),()->volume("increment")});
        gap(content,14);Button refresh=button("↻ 刷新播放状态",false);refresh.setOnClickListener(v->refreshRemote());add(content,refresh);
    }
    private void rowButtons(LinearLayout into,String[] names,Runnable[] clicks) {
        LinearLayout row=horizontal();
        for(int i=0;i<names.length;i++) {
            Button b=button(names[i],i==0&&names.length==2);final Runnable run=clicks[i];
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(58),1);lp.setMargins(dp(3),0,dp(3),0);
            row.addView(b,lp);b.setOnClickListener(v->run.run());
            if(names.length>=4)b.setTextSize(10);
        }
        add(into,row);
    }
    private void seek(int seconds) { playerAction("Player.Seek","value",seconds); }
    private void playerAction(String method,String key,Object value) {
        int id=activePlayerId;if(id<0){toast("Kodi 没有正在播放的内部播放器；外部 Vimu 不支持 Kodi RPC 控制");return;}
        async(()->{
            Object val=value;
            if("Player.Seek".equals(method))val=KodiClient.obj("seconds",value);
            kodi.playerCommand(method,id,key,val);return null;
        },(d,e)->{if(e!=null)toast("控制失败："+e.getMessage());else refreshRemote();});
    }
    private void volume(String cmd) {
        async(()->{kodi.volume(cmd);return null;},(d,e)->{
            if(e!=null)toast("音量失败："+e.getMessage());
            else toast("已向 Kodi 发出音量指令。电视固定音量输出时可能无效。");
        });
    }
    private void mute() {async(()->{kodi.mute();return null;},(d,e)->{if(e!=null)toast(e.getMessage());});}
    private void refreshRemote() {
        if(page!=2||remoteStatus==null)return;
        async(()->{
            int id=kodi.activePlayer();
            if(id<0)return new Object[]{-1,null,"Kodi 无活动播放器（可能正在由 Vimu 播放）"};
            JSONObject p=kodi.playerProperties(id);
            return new Object[]{id,p,kodi.playerItemTitle(id)};
        },(data,err)->{
            if(page!=2||remoteStatus==null)return;
            if(err!=null){remoteStatus.setText("连接失败："+err.getMessage());activePlayerId=-1;return;}
            Object[] arr=(Object[])data;activePlayerId=(Integer)arr[0];remoteStatus.setText((String)arr[2]);
            if(activePlayerId>=0&&arr[1]!=null) {
                JSONObject p=(JSONObject)arr[1];remoteSeek.setProgress((int)(p.optDouble("percentage",0)*10));
            } else remoteSeek.setProgress(0);
        });
    }
    private void renderSettings() {
        add(content,text("连接设置",26,TEXT,true));gap(content,8);
        add(content,text("Fold6 ↔ 同一 Wi-Fi 内的 Google TV / Kodi",13,SUB,false));gap(content,20);
        EditText host=field(content,"Kodi IP 地址",kodi.host(),"例如 192.168.0.79",false);
        EditText port=field(content,"Kodi HTTP 端口",""+kodi.port(),"8080",false);
        port.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        EditText user=field(content,"Kodi 用户名",kodi.user(),"Kodi 网页服务账户",false);
        EditText pass=field(content,"Kodi 密码",kodi.password(),"未设密码则留空",true);
        gap(content,10);
        Button save=button("保存并检测连接",true);add(content,save);
        save.setOnClickListener(v->{
            int p;
            try {p=Integer.parseInt(port.getText().toString().trim());if(p<1||p>65535)throw new NumberFormatException();}
            catch(NumberFormatException e){toast("端口必须为 1–65535");return;}
            String h=host.getText().toString().trim();
            if(h.isEmpty()||h.contains("/")||h.contains(":")){toast("请输入 IP 地址，不要包含 http:// 或端口");return;}
            kodi.prefs().edit().putString("host",h).putInt("port",p)
                    .putString("user",user.getText().toString()).putString("password",pass.getText().toString()).apply();
            async(()->kodi.rpc("JSONRPC.Ping",null),(data,err)->{
                if(err!=null)new AlertDialog.Builder(this).setTitle("连接失败").setMessage(err.getMessage()).setPositiveButton("确定",null).show();
                else {toast("Kodi 连接成功！");loadHome();}
            });
        });
        gap(content,24);label(content,"电视端需要设置");
        TextView setup=text("1. Kodi 设置 → 服务 → 控制 → 允许通过 HTTP 远程控制。\n\n2. Kodi → 视频 → 文件 → 添加 SMB 视频源。\n\n3. 希望 Kodi 播放时交给 Vimu：把压缩包里的 playercorefactory.xml 放进 Kodi userdata 文件夹，再重启 Kodi。\n\n4. 若要展示完整海报、剧情、评分：在 Kodi 为 SMB 目录设置影片/电视剧内容并扫描入库。",13,SUB,false);
        padding(setup,15,15,15,15);setup.setBackground(bg(SURFACE,14));add(content,setup);
        gap(content,14);
        TextView caution=text("注意：Vimu 接管视频后，Kodi 的 RPC 快进/暂停/音量不能直接控制它。只在可信局域网中启用 Kodi HTTP 服务。",12,0xFFEFC28C,false);
        padding(caution,14,14,14,14);caution.setBackground(bg(0xFF382C23,13));add(content,caution);
    }
    private EditText field(LinearLayout to,String title,String value,String hint,boolean pass) {
        TextView lbl=text(title,13,SUB,true);padding(lbl,2,0,0,7);add(to,lbl);
        EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setHint(hint);
        e.setTextSize(15);e.setTextColor(TEXT);e.setHintTextColor(0xFF8194A8);
        padding(e,14,10,14,10);e.setBackground(stroke(SURFACE,12,0xFF2D4158));
        if(pass)e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        add(to,e);gap(to,15);return e;
    }
}
