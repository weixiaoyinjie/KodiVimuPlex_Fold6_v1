# Kodi Vimu Plex · Fold6

一个原生 Java Android 手机控制端：深色 Plex 风格电影库、电视剧海报、Kodi 资料库搜索、SMB 视频文件夹、文件名封面、Kodi 遥控、点播交给 Kodi 的外部播放器规则处理。

**一款手机 APK。** 电视只需要 Kodi 和 Vimu；不需要 TV bridge APK、后端服务器，也不需要另买海报 API。

## 项目能力

| 功能 | 当前实现 |
|---|---|
| Kodi JSON-RPC 连接测试、账号密码保存 | ✅ |
| 电影海报、fanart、剧情、年份、评分 | ✅ 有 Kodi 媒体库元数据时 |
| 电视剧与剧集、搜索、继续观看列表 | ✅ 继续观看数据来自 Kodi |
| Kodi 视频源列表、SMB 文件夹浏览 | ✅ 通过 Files.GetSources/GetDirectory |
| Kodi /image/ 缩略图；SMB 同名 jpg/folder.jpg | ✅ 通过 Kodi HTTP /image 和 /vfs 代理，文件需要可读 |
| 点击手机影视库的视频在电视播放 | ✅ Kodi Player.Open JSON-RPC |
| Kodi 内置播放器暂停/快进10秒/播放进度/音量 | ✅ Kodi 内部播放时 |
| 手机上一部/下一部 | ✅ 向 Kodi 发送上一/下一视频 Player.Open |
| 由 Kodi 自动转交 Vimu | ⚠️ 需要电视 playercorefactory.xml，且实际 Vimu 包名与 SMB 访问必须匹配 |
| Vimu 播放时直接快进、精确播放进度、音量、暂停 | ❌ Kodi RPC 不能控制外部 Vimu |

## TV 设置

1. **Kodi → 设置 → 服务 → 控制**：开启 *允许通过 HTTP 远程控制*，检查 IP（Google TV 的当前 Wi-Fi IP）、端口（常见 `8080`）和账号密码。务必只在可信内网启用。
2. Kodi **视频 → 文件 → 添加视频**：输入 SMB 网络源并确认能浏览。电影/电视剧若需要剧情、海报，需设置内容类型、选择刮削器并扫描入库。
3. 需要 Vimu 接管：参见 `tv-config/README_电视端.txt`。按照实际 Vimu 包名选择 `playercorefactory_vimu_paid.xml` 或 `playercorefactory_vimu_free.xml`，重命名为 `playercorefactory.xml` 放到 Kodi `userdata` 目录，重启 Kodi。
4. **优先先在电视 Kodi 上测试一部 SMB 视频能否自动拉起 Vimu**。如果失败，检查 Vimu 实际包名、Vimu 自己的 SMB 登录凭证、Kodi 版本；删除 XML 重启即可回退。

Kodi 官方说明：<https://kodi.wiki/view/HOW-TO:Use_external_players_on_Android>
Kodi artwork API：<https://kodi.wiki/view/Artwork/Accessing_with_skins_and_JSON-RPC>
Vimu API（Android intent）：<https://vimu.tv/player-api/>

## 源码直接编译

Gradle 8.9、JDK 17、Android SDK 35；Android Gradle Plugin 8.7.3。项目 GitHub Actions `/.github/workflows/android.yml` 会自动执行 `gradle :app:assembleDebug`，生成 `app-debug.apk`。支持最低 Android 8.0。

上传源代码到 GitHub 新仓库 **需要解压 ZIP 后上传里面的文件/文件夹**；GitHub 网页“Upload files”不会自动解压 ZIP。

如果你坚持**只上传一个 ZIP** 到仓库根目录：使用压缩包外附的 `build-one-upload.yml` 内容，在仓库中手动新建 `.github/workflows/build.yml`，它会找到根目录 ZIP、解压并编译。注意仅上传 ZIP 本身并不能自动启用 GitHub Actions，需要添加 workflow 文件。

APK 下载：GitHub 仓库 → Actions → 最新成功的 Build Android APK / One-Upload Build → Artifacts。

## 安全 / 已知约束

- Kodi HTTP 是**明文 HTTP + Basic auth**：只在家庭可信 Wi-Fi 中使用，勿将 Kodi 8080 端口开放到公网。应用账号保存在 Android 应用私有 SharedPreferences 中，不会上传到云端。
- Vimu 通过外部播放器 XML 被调用时，Kodi JSON-RPC 并不能返回 Vimu 的真实播放位置与控制状态。需要真正的 Vimu 远控，后续必须另做经用户许可的 TV 端控制层或确认 Vimu 支持的官方控制方式。
- Vimu 本身能够访问 SMB 并不意味着能自动获得 Kodi 已保存的 SMB 账户信息，必要时需要在 Vimu 中配置同一共享。
- Kodi **未刮削**的 SMB 视频通常没有剧情/海报；已有 Kodi 缓存图会显示，另外支持匹配 `电影名.jpg`、`poster.jpg`、`folder.jpg` 文件。应用不会凭空生成视频帧缩略图。
- 前版未在你的真实 Google TV + SMB + Vimu 环境中实机验证；GitHub 编译是否成功也需按 Actions 日志最终确认。
